#!/bin/bash
set -e

# Load configuration
source deploy-config.sh

echo "========================================="
echo "🔧 Configuring ONLY RAG Access for Agent"
echo "========================================="
echo "Agent: search_assistant (agent-001)"
echo "Action: Remove all tools, add ONLY RAG"
echo "Corpus: grupodc-sharepoint-rag-corpus-dev"
echo "========================================="

# Start Cloud SQL Proxy if needed
if [ ! -f "./cloud-sql-proxy" ]; then
  echo "📥 Downloading Cloud SQL Proxy..."
  curl -o cloud-sql-proxy https://storage.googleapis.com/cloud-sql-connectors/cloud-sql-proxy/v2.8.0/cloud-sql-proxy.linux.amd64
  chmod +x cloud-sql-proxy
fi

export CONNECTION_NAME=$(gcloud sql instances describe $DB_INSTANCE_NAME \
  --format='value(connectionName)')

echo "🔌 Starting Cloud SQL Proxy..."
./cloud-sql-proxy $CONNECTION_NAME &
PROXY_PID=$!
sleep 5

# Show current tools
echo ""
echo "📋 Current tools for agent-001:"
PGPASSWORD="$DB_APP_PASSWORD" psql -h 127.0.0.1 -U $DB_USER -d $DB_NAME <<EOF
SELECT t.tool_name, t.tool_type, t.description
FROM agent_tools at
JOIN tools t ON at.tool_id = t.tool_id
WHERE at.agent_id = 'agent-001';
EOF

echo ""
echo "🔄 Running migration to configure RAG-only access..."
PGPASSWORD="$DB_APP_PASSWORD" psql -h 127.0.0.1 -U $DB_USER -d $DB_NAME \
  -f migrations/006_assign_rag_to_default_agent.sql

# Verify the configuration
echo ""
echo "✅ New configuration for agent-001:"
PGPASSWORD="$DB_APP_PASSWORD" psql -h 127.0.0.1 -U $DB_USER -d $DB_NAME <<EOF
SELECT 
    a.name as agent_name,
    a.description,
    t.tool_name,
    t.tool_type,
    c.display_name as corpus_name,
    ac.priority
FROM agents a
LEFT JOIN agent_tools at ON a.agent_id = at.agent_id
LEFT JOIN tools t ON at.tool_id = t.tool_id
LEFT JOIN agent_corpuses ac ON a.agent_id = ac.agent_id
LEFT JOIN corpuses c ON ac.corpus_id = c.corpus_id
WHERE a.agent_id = 'agent-001';
EOF

# Stop proxy
kill $PROXY_PID 2>/dev/null || true

echo ""
echo "========================================="
echo "✅ Configuration Complete!"
echo "========================================="
echo ""
echo "Agent 'search_assistant' now has:"
echo "  ✅ RAG search tool ONLY"
echo "  ✅ Access to SharePoint corpus"
echo "  ❌ No web search"
echo "  ❌ No weather tool"
echo "  ❌ No other tools"
echo ""
echo "========================================="

