import os
import vertexai
from vertexai import rag

os.environ["GOOGLE_CLOUD_PROJECT"] = "delfosti-grupodc-polidc-dev"

vertexai.init(
    project="delfosti-grupodc-polidc-dev",
    location="us-east4"
)

try:
    print("🔍 Testing RAG retrieval...")
    response = rag.retrieval_query(
        rag_resources=[
            rag.RagResource(
                rag_corpus="projects/delfosti-grupodc-polidc-dev/locations/us-east4/ragCorpora/4611686018427387904",
            )
        ],
        text="test query",
        similarity_top_k=3,
        vector_distance_threshold=0.5,
    )
    
    print("✅ RAG API call succeeded!")
    print(f"Response: {response}")
    
    if hasattr(response, 'contexts') and response.contexts:
        print(f"Found {len(response.contexts.contexts)} results")
    else:
        print("⚠️ No contexts in response")
        
except Exception as e:
    print(f"❌ RAG API call failed: {e}")
    import traceback
    traceback.print_exc()
