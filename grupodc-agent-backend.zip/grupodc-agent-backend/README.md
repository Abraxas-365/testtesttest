# 🔵 **DOCUMENTACIÓN COMPLETA: Sistema de Agentes Conversacionales con Microsoft Teams, Azure y Google Cloud**

---

## **📋 Índice**

1. [Resumen Ejecutivo](#1-resumen-ejecutivo)
2. [Azure AD (Entra ID) - Configuración](#2-azure-ad-entra-id---configuración)
3. [Microsoft Teams - Integración](#3-microsoft-teams---integración)
4. [SharePoint - Configuración de Datos](#4-sharepoint---configuración-de-datos)
5. [Google Cloud Platform - Servicios](#5-google-cloud-platform---servicios)
6. [Arquitectura del Sistema](#6-arquitectura-del-sistema)
7. [Stack Tecnológico](#7-stack-tecnológico)
8. [Estructura del Repositorio](#8-estructura-del-repositorio)
9. [Modelo de Datos y Relaciones](#9-modelo-de-datos-y-relaciones)
10. [Despliegue y Administración](#11-despliegue-y-administración)
11. [Monitoreo y Troubleshooting](#12-monitoreo-y-troubleshooting)

---

## **1. Resumen Ejecutivo**

Sistema de agentes conversacionales inteligentes integrado con **Microsoft Teams**, utilizando **Google Cloud Platform** para procesamiento de IA y **Azure Active Directory** para autenticación y autorización basada en grupos de seguridad.

### **Características principales:**
- ✅ Integración nativa con Microsoft Teams (bot framework)
- ✅ RAG (Retrieval-Augmented Generation) con documentos SharePoint
- ✅ Routing automático basado en grupos de Azure AD
- ✅ Soporte para archivos PDF/DOCX con análisis por IA
- ✅ Persistencia de sesiones y historial conversacional
- ✅ Arquitectura escalable y tolerante a fallos

### **📊 Costos Estimados Mensuales**
```
Cloud Run (min-instances=1):     $40-50/mes
Cloud SQL (PostgreSQL 16):      $40-60/mes
Vertex AI RAG:                   Variable según uso
Secret Manager:                  <$1/mes
Cloud Build:                     <$5/mes
--------------------------------
TOTAL ESTIMADO:                  $85-115/mes
```

---

## **2. Azure AD (Entra ID) - Configuración**

### ✅ **2.1. Tenant de Azure AD - Dominio Verificado**

**Step-by-Step:**

1. **Sign in to Microsoft Entra Admin Center as Global Administrator**
   - Go to https://entra.microsoft.com

2. **Navigate to Domain Names**
   - Browse to **Identity > Settings > Domain names**
   - Click **Add custom domain**

3. **Add Your Custom Domain**
   - Enter your organization's domain (e.g., yourdomain.com)
   - Click **Add domain**

4. **Get DNS Verification Records**
   - Copy the TXT record information provided (Name, Type, Value, TTL)

5. **Add DNS Record at Your Domain Registrar**
   - Log into your domain registrar (GoDaddy, Namecheap, etc.)
   - Navigate to DNS management
   - Create new TXT record with copied values
   - Set TTL to 3600 seconds (1 hour)
   - Save changes

6. **Verify Domain in Azure**
   - Return to Entra admin center
   - Click **Verify** on your custom domain
   - Wait for verification (can take up to 24 hours)

7. **Set as Primary Domain (Optional)**
   - Select your verified custom domain
   - Click **Make primary**
   - Confirm the change

---

### ✅ **2.2. App Registration - teams-agent-app**

**Step-by-Step:**

1. **Navigate to App Registrations**
   - Go to **Microsoft Entra ID > App registrations**
   - Click **New registration**

2. **Configure Basic Settings**
   - **Name:** `teams-agent-app`
   - **Supported account types:** Select based on your needs:
     - Single tenant (your organization only)
     - Multi-tenant (any organizational directory)
   - **Redirect URI:** Leave blank for now (can add later)
   - Click **Register**

3. **Copy Application (Client) ID**
   - Save the **Application (client) ID** - you'll need this later
   - Save the **Directory (tenant) ID**

---

### ✅ **2.3. Configure API Permissions**

**Step-by-Step:**

1. **Navigate to API Permissions**
   - In your app registration, go to **API permissions**
   - Click **Add a permission**

2. **Add Microsoft Graph Permissions**
   - Select **Microsoft Graph > Delegated permissions**
   - Add the following permissions:
     - `User.Read`
     - `User.ReadBasic.All`
     - `Directory.Read.All`
     - `Sites.Read.All`
     - `Files.Read.All`
     - `ChannelMessage.Read.All`
   - Click **Add permissions**

3. **Grant Admin Consent**
   - Click **Grant admin consent for [Your Organization]**
   - Confirm by clicking **Yes**
   - Wait for status to show "Granted for [Your Organization]"

---

### ✅ **2.4. Generate Client Secret**

**Step-by-Step:**

1. **Navigate to Certificates & Secrets**
   - In your app registration, go to **Certificates & secrets**
   - Click **New client secret**

2. **Create Secret**
   - **Description:** Enter a meaningful description (e.g., "Teams Agent App Secret")
   - **Expires:** Select expiration period (recommended: 24 months for production)
   - Click **Add**

3. **Copy Secret Value**
   - ⚠️ **IMPORTANT:** Copy the **Value** immediately - it won't be shown again
   - Store securely (password manager, Azure Key Vault, etc.)
   - Also note the Secret ID

---

### ✅ **2.5. Grupos de Seguridad**

**Step-by-Step:**

1. **Navigate to Groups**
   - Go to **Microsoft Entra ID > Groups**
   - Click **New group**

2. **Create Security Groups**
   - **Group type:** Security
   - **Group name:** `Legal-Users`
   - **Group description:** "Legal department users"
   - **Membership type:** Assigned (or Dynamic if you want rules-based membership)
   - Click **Create**

3. **Create Additional Groups**
   - Create `HR-Users` group
   - Create `Admin-Users` group
   - Create `Marketing-Users` group

4. **Add Members to Groups**
   - Click on each group
   - Go to **Members > Add members**
   - Search and select users
   - Click **Select**

---

## **3. Microsoft Teams - Integración**

### ✅ **3.1. Bot Framework Registration**

**Step-by-Step:**

1. **Navigate to Azure Portal**
   - Go to https://portal.azure.com
   - Click **Create a resource**

2. **Search and Create Azure Bot**
   - Search for "Azure Bot"
   - Click **Create**

3. **Configure Bot Settings**
   - **Bot handle:** Enter unique name (e.g., `teams-agent-bot`)
   - **Subscription:** Select your Azure subscription
   - **Resource group:** Create new or select existing
   - **Location:** Select your region
   - **Pricing tier:** F0 (Free) for development, S1 for production

4. **Configure Microsoft App ID**
   - **Type:** Select "User-Assigned Managed Identity" (recommended) or "Single Tenant"
   - **Creation type:** Select "Use existing app registration"
   - **App ID:** Enter the Application (Client) ID from your app registration
   - **App tenant ID:** Enter your tenant ID

5. **Create the Bot**
   - Click **Review + create**
   - Click **Create**
   - Wait for deployment to complete

---

### ✅ **3.2. Configure Messaging Endpoint**

**Step-by-Step:**

1. **Get Your Bot Service URL**
   - This will be your deployed web app URL (e.g., `https://yourbot.azurewebsites.net`)
   - Or use ngrok for local development: `https://your-subdomain.ngrok.io`

2. **Configure Endpoint in Azure Bot**
   - Go to your Azure Bot resource
   - Click **Configuration**
   - **Messaging endpoint:** Enter `https://your-bot-url.com/api/messages`
   - **Enable Streaming Endpoint:** Check this option
   - Click **Apply**

---

### ✅ **3.3. Enable Microsoft Teams Channel**

**Step-by-Step:**

1. **Navigate to Channels**
   - In your Azure Bot resource
   - Click **Channels** in the left menu

2. **Add Microsoft Teams Channel**
   - Click on the Microsoft Teams icon
   - Accept the Terms of Service
   - Configure settings:
     - **Messaging:** Enable
     - **Calling:** Enable if needed
   - Click **Save**

3. **Test Connection**
   - Click on Microsoft Teams in the channels list
   - Click **Open in Teams** to test

---

### ✅ **3.4. Teams App Package (Manifest.json)**

**Step-by-Step:**

1. **Create Manifest File Structure**
```
YourTeamsApp/
├── manifest.json
├── color.png (192x192)
└── outline.png (32x32)
```

2. **Create manifest.json**
```json
{
  "$schema": "https://developer.microsoft.com/json-schemas/teams/v1.16/MicrosoftTeams.schema.json",
  "manifestVersion": "1.16",
  "version": "1.0.0",
  "id": "YOUR-APP-ID-GUID",
  "packageName": "com.yourcompany.teamsagent",
  "developer": {
    "name": "Your Company",
    "websiteUrl": "https://yourwebsite.com",
    "privacyUrl": "https://yourwebsite.com/privacy",
    "termsOfUseUrl": "https://yourwebsite.com/terms"
  },
  "name": {
    "short": "Teams Agent",
    "full": "Teams Agent Application"
  },
  "description": {
    "short": "AI-powered Teams agent",
    "full": "Full description of your Teams agent application"
  },
  "icons": {
    "outline": "outline.png",
    "color": "color.png"
  },
  "accentColor": "#FFFFFF",
  "bots": [
    {
      "botId": "YOUR-BOT-APP-ID",
      "scopes": ["personal", "team", "groupchat"],
      "supportsFiles": false,
      "isNotificationOnly": false,
      "commandLists": [
        {
          "scopes": ["personal", "team", "groupchat"],
          "commands": [
            {
              "title": "help",
              "description": "Get help using the bot"
            }
          ]
        }
      ]
    }
  ],
  "permissions": ["identity", "messageTeamMembers"],
  "validDomains": ["token.botframework.com", "*.ngrok.io"]
}
```

3. **Create Icon Files**
   - **color.png:** 192x192 pixels, full color icon
   - **outline.png:** 32x32 pixels, transparent background with white outline

4. **Package as ZIP**
   - Select all three files (manifest.json, color.png, outline.png)
   - Create ZIP archive named `TeamsApp.zip`
   - Do NOT include folder in ZIP, files should be at root level

---

### ✅ **3.5. Deploy to Teams Admin Center**

**Option 1: Teams Admin Center (Organization-wide)**

1. **Navigate to Teams Admin Center**
   - Go to https://admin.teams.microsoft.com
   - Sign in as Teams Administrator

2. **Upload Custom App**
   - Go to **Teams apps > Manage apps**
   - Click **Upload new app**
   - Click **Upload** and select your `TeamsApp.zip`
   - Click **Submit**

3. **Set App Availability**
   - Find your app in the list
   - Click on it
   - Go to **Publishing status**
   - Click **Publish** to make available organization-wide

**Option 2: Teams Developer Portal (Individual/Testing)**

1. **Go to Teams Developer Portal**
   - Go to https://dev.teams.microsoft.com
   - Sign in with your account

2. **Import App**
   - Click **Apps** in left menu
   - Click **Import app**
   - Upload your `TeamsApp.zip`

3. **Validate and Publish App**
   - Review app details
   - Click **Validate** to check for errors
   - Fix any issues reported
   - Click **Publish > Publish to org**

---

## **4. SharePoint - Configuración de Datos**

### ✅ **4.1. Client ID and Client Secret**

You should already have these from your App Registration:

**What You Need:**

| Field | Example | Notes |
|:---|:---|:---|
| Client ID | `12345678-abcd-1234-efgh-1234567890ab` | Application (client) ID |
| Client Secret | `abc~123xyz...` | Copy immediately when created |
| Tenant ID | `87654321-dcba-4321-hgfe-0987654321ba` | Directory (tenant) ID |

---

### ✅ **4.2. SharePoint Site Name**

**Method 1: From SharePoint URL (Easiest)**

1. Open your SharePoint site in a browser
2. Look at the URL:
   ```
   https://[YOUR-COMPANY].sharepoint.com/sites/[SITE-NAME]
   ```
3. Site Name = `[SITE-NAME]`

**Examples:**
- URL: `https://contoso.sharepoint.com/sites/Legal`
- Site Name: `Legal`

---

### ✅ **4.3. Drive Name (Document Library)**

**Method 1: From SharePoint UI**

1. Navigate to your SharePoint site
2. Click on **Site contents**
3. Look for document libraries (default is usually "Documents")

**Common Drive Names:**
- `Documents` (default in English)
- `Shared Documents`
- Custom names like: `Legal Documents`, `Contratos`, `HR Files`

---

### ✅ **4.4. Comandos cURL para Obtener Datos de SharePoint**

#### **Paso 1: Obtener Access Token**

```bash
curl -X POST \
  "https://login.microsoftonline.com/44a78b44-3fba-4ad7-b951-6bbdc7b98cdb/oauth2/v2.0/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "client_id=0c9cd352-368b-4b96-b1b5-780d85a724b4" \
  -d "client_secret=fJD8Q~sbgibbi7FRaByL~WDa1hk5M1w5zP4eYcoI" \
  -d "scope=https://graph.microsoft.com/.default" \
  -d "grant_type=client_credentials"
```

#### **Paso 2: Obtener Site ID**

```bash
curl -X GET \
  "https://graph.microsoft.com/v1.0/sites/delfostipe.sharepoint.com:/sites/TeamDesarrollo2-Proyectos" \
  -H "Authorization: Bearer {TU_ACCESS_TOKEN}"
```

#### **Paso 3: Obtener Drive Name**

```bash
curl -X GET \
  "https://graph.microsoft.com/v1.0/sites/{SITE_ID}/drives" \
  -H "Authorization: Bearer {TU_ACCESS_TOKEN}"
```

### **📋 Configuration Summary**

| Field | Example Value | Where to Obtain |
|:---|:---|:---|
| Client ID | `0c9cd352-368b-4b96-b1b5-780d85a724b4` | Azure AD > App Registration > Overview |
| Client Secret | `fJD8Q~sbgibbi7FRaByL~WDa1hk5M1w5zP4eYcoI` | Azure AD > App Registration > Certificates & secrets |
| Tenant ID | `44a78b44-3fba-4ad7-b951-6bbdc7b98cdb` | Azure AD > App Registration > Overview |
| SharePoint Domain | `delfostipe.sharepoint.com` | SharePoint URL (first part) |
| Site Name | `TeamDesarrollo2-Proyectos` | SharePoint URL: `/sites/TeamDesarrollo2-Proyectos` |
| Drive Name | `Documents` | SharePoint > Site contents > Library name |
| Site ID | `delfostipe.sharepoint.com,a1be7e65-9ecd...` | Microsoft Graph API query |

---

## **5. Google Cloud Platform - Servicios**

### ✅ **5.1. Servicios Activos**

| Servicio | Propósito | Configuración | Estado |
|----------|-----------|---------------|--------|
| **Cloud Run** | Hosting del backend API | `min-instances=1`, `1Gi RAM`, `1 CPU` | ✅ Activo |
| **Cloud SQL (PostgreSQL 16)** | Base de datos principal | `db-custom-1-3840`, `10GB` storage | ✅ Activo |
| **Vertex AI Search** | Motor RAG con SharePoint | RagManaged, embedding `text-multilingual-embedding-002` | ✅ Activo |
| **Secret Manager** | Credenciales seguras | `db-password`, `graph-client-secret` | ✅ Activo |
| **Cloud Build** | CI/CD para contenedores | `n1-standard-1` | ✅ Activo |

### ✅ **5.2. Vertex AI Search (Motor de RAG)**

**Configuración del Corpus:**

| Parámetro | Valor Recomendado | Descripción |
|:---|:---|:---|
| **Modelo de embedding** | `Text Multilingual Embedding 002` | Modelo de Google para generar vectores de documentos. Soporta múltiples idiomas. |
| **Base de datos de vectores** | **Almacén de vectores RagManaged** | ⭐ Opción seleccionada. Utiliza Spanner administrado por RAG. Ideal para un inicio rápido. |

### ✅ **5.3. Cloud SQL (PostgreSQL)**

**Configuración Recomendada:**

| Parámetro | Valor Recomendado | Descripción |
|:---|:---|:---|
| **`--database-version`** | `POSTGRES_16` | Versión más reciente de PostgreSQL. |
| **`--tier`** | `db-custom-1-3840` | 1 vCPU, 3.84 GB RAM. Adecuado para desarrollo y producción inicial. |
| **`--storage-size`** | `10GB` | Tamaño inicial del disco. Se puede aumentar automáticamente. |
| **`--storage-auto-increase`** | Habilitado | Permite que el almacenamiento crezca automáticamente. |
| **`--backup-start-time`** | `03:00` | Hora para iniciar los backups automáticos diarios. |
| **`--no-assign-ip`** | Habilitado | No asigna IP pública, mejorando la seguridad. |

### ✅ **5.4. Cloud Run**

**Configuración Recomendada:**

| Parámetro | Valor Recomendado | Descripción |
|:---|:---|:---|
| **`--memory`** | `1Gi` | Memoria asignada a cada instancia. |
| **`--cpu`** | `1` | CPU asignada a cada instancia. |
| **`--min-instances`** | `1` | ⭐ Solución al "Cold Start": Mantiene 1 instancia siempre activa. |
| **`--max-instances`** | `10` | Número máximo de instancias para escalar bajo carga. |
| **`--timeout`** | `300s` | Tiempo máximo de espera (5 minutos). |
| **`--concurrency`** | `80` | Número de peticiones simultáneas por instancia. |

**Opciones según Presupuesto:**

**Opción 1: Sin Cold Start (Recomendada para Producción)**
```bash
--min-instances 1
--max-instances 10
```
- ✅ Respuesta inmediata
- ❌ Costo: ~$40-50/mes por instancia siempre activa

**Opción 2: Con Cold Start (Ahorro de Costos)**
```bash
--min-instances 0
--max-instances 10
```
- ✅ Costo: Solo pagas por uso
- ❌ Primera petición después de inactividad tarda 5-10 segundos

---

## **6. Arquitectura del Sistema**

### 🏗️ **6.1. Arquitectura Conceptual**

```mermaid
graph TD
    User[Usuario Teams] --> AADGroup[Grupo Azure AD]
    AADGroup --> Mapping[Group Mapping]
    Mapping --> AreaType[area_type]
    AreaType --> Agent[Agente]
    
    Agent --> Tool[Herramienta]
    Agent --> Corpus[Corpus RAG]
    Agent --> SubAgent[Sub-Agente]
    
    Corpus --> SharePoint[SharePoint Docs]
    Corpus --> VertexAI[Vertex AI RAG]
    
    Tool --> RAGTool[RAG Tool]
    Tool --> FunctionTool[Function Tool]
    Tool --> AgentTool[Agent Tool]
    
    Agent --> Session[Sesión]
    Session --> Events[Eventos/Mensajes]
```

### 🧠 **6.2. ¿Qué es un Agente?**

Un **Agente** es una entidad conversacional inteligente con las siguientes características:

```yaml
Definición: Instancia especializada de IA conversacional
Componentes:
  - Modelo LLM: gemini-2.5-flash, gemini-2.5-pro, etc.
  - Instrucciones: Personalidad y comportamiento específico
  - Herramientas: Funciones que puede ejecutar
  - Corpus: Bases de conocimiento que puede consultar
  - Área de especialización: Dominio de expertise (legal, marketing, etc.)

Ejemplo Conceptual:
  Agente Legal:
    - Personalidad: "Eres un asesor legal especializado"
    - Herramientas: [rag_search_legal, document_analyzer]
    - Corpus: [legal_documents, contracts, policies]
    - Área: "legal"
```

### 📚 **6.3. ¿Qué es un Corpus?**

Un **Corpus** es una colección organizada de conocimiento vectorizado:

```yaml
Definición: Base de conocimiento indexada para búsqueda semántica
Componentes:
  - Documentos fuente: SharePoint, GCS, archivos locales
  - Embeddings: Representaciones vectoriales del contenido
  - Metadatos: Información sobre los documentos
  - Configuración de búsqueda: Parámetros de relevancia

Ejemplo Conceptual:
  Corpus Legal:
    - Fuente: SharePoint/sites/Legal/Documents
    - Contenido: Contratos, políticas, procedimientos legales
    - Embeddings: text-multilingual-embedding-002
    - Metadatos: Autor, fecha, tipo documento, versión
```

### 🎯 **6.4. Mapeo Azure Groups → Agents**

**Flujo de Routing Automático:**

```mermaid
sequenceDiagram
    participant U as Usuario Teams
    participant AAD as Azure AD
    participant GM as Group Mapper
    participant AR as Agent Router
    participant A as Agente

    U->>AAD: Autenticación
    AAD->>GM: Grupos del usuario ["Legal-Users", "All-Employees"]
    GM->>GM: Evalúa pesos (Legal=900, All=100)
    GM->>AR: area_type = "legal"
    AR->>AR: Busca agente con area_type="legal"
    AR->>A: Selecciona "Legal Advisor"
    A->>U: Respuesta especializada
```

**Ejemplos de Mapeo:**

```yaml
Group Mapping Logic:
  Usuario en ["Legal-Users"]:
    → area_type = "legal" 
    → Agente "Legal Advisor"
    
  Usuario en ["Marketing-Users", "All-Employees"]:
    → area_type = "marketing" (weight=700 > weight=100)
    → Agente "Marketing Specialist"
    
  Usuario en ["HR-Users", "Legal-Users"]:
    → area_type = "legal" (weight=900 > weight=850)
    → Agente "Legal Advisor"
    
  Usuario sin grupos o grupos no mapeados:
    → area_type = "general" (fallback)
    → Agente "General Assistant"
```

### 🛠️ **6.5. Tipos de Herramientas**

```yaml
Tool Types:
  
  RAG Tool:
    Purpose: Búsqueda semántica en corpus de conocimiento
    Implementation: Vertex AI RAG Engine
    Example: "search_legal_documents" → "legal_corpus"
    
  Function Tool:
    Purpose: Ejecutar funciones Python específicas
    Examples: calculate(), get_weather(), search_web()
    
  Agent Tool:
    Purpose: Delegar tareas a otros agentes
    Example: "data_analyst_tool" → Agent "Data Analyst"
    
  Builtin Tool:
    Purpose: Herramientas nativas del ADK
    Examples: Code execution, image analysis
```

---

## **7. Stack Tecnológico**

### 🐍 **Backend Framework**
```yaml
Framework: FastAPI
Version: 0.115.0
Características:
  - Async/await nativo
  - Validación automática con Pydantic
  - OpenAPI/Swagger integrado
  - Type hints completo
```

### 🤖 **SDK de IA**
```yaml
SDK Principal: Google ADK (Agent Development Kit)
Version: 1.0.0
Complementos:
  - google-genai: 0.2.0
  - vertexai: Último (auto-actualizado)
  
Modelos LLM utilizados:
  - gemini-2.5-flash (agente principal)
  - gemini-2.5-pro (agentes especializados)
  - text-multilingual-embedding-002 (embeddings RAG)
```

### 🗄️ **Base de Datos**
```yaml
Motor: PostgreSQL
Version: 16 (última estable)
Driver Python: asyncpg 0.29.0
Driver Sincrónico: psycopg2-binary 2.9.9 (para ADK)
ORM: SQLAlchemy 2.0+ (para ADK DatabaseSessionService)
```

### ☁️ **Integración Cloud**
```yaml
GCP SDKs:
  - google-cloud-storage
  - google-cloud-secretmanager
  - vertexai
  
Microsoft SDKs:
  - msgraph-sdk: 1.0.0+
  - azure-identity: 1.12.0+
  
HTTP Client:
  - httpx: 0.27.0+ (async)
  - requests: 2.32.3 (legacy/sync)
```

### 📄 **Procesamiento de Documentos**
```yaml
PDF: PyPDF2 3.0.1
DOCX: python-docx 1.1.0
Método: Extracción de texto + análisis con Gemini
Sanitización: Limpieza para PostgreSQL JSONB
```

---

## **8. Estructura del Repositorio**

### 📁 **Organización por Capas (Clean Architecture)**

```
grupodc-agent-backend/
├── src/                          # Código fuente principal
│   ├── domain/                   # CAPA DE DOMINIO (Business Logic)
│   │   ├── models/               # Modelos de negocio
│   │   │   ├── agent_config.py   # Config. agentes, herramientas, corpus
│   │   │   ├── azure_ad_models.py # Modelos Azure AD group mappings
│   │   │   └── session_models.py  # Sesiones y mensajes
│   │   ├── ports/                # Interfaces (contratos)
│   │   │   ├── agent_repository.py
│   │   │   ├── corpus_repository.py
│   │   │   └── group_mapping_repository.py
│   │   └── services/             # Servicios de dominio
│   │       └── agent_service.py  # Lógica principal de agentes
│   │
│   ├── application/              # CAPA DE APLICACIÓN (Use Cases)
│   │   ├── api/                  # Controladores REST
│   │   │   ├── routes.py         # API general (/agents, /invoke)
│   │   │   ├── teams_routes.py   # API Microsoft Teams (/teams/message)
│   │   │   ├── group_mapping_routes.py # API grupos AD (/groups/mappings)
│   │   │   └── session_routes.py # API sesiones (/sessions)
│   │   └── di/                   # Dependency Injection
│   │       └── container.py      # Contenedor IoC
│   │
│   ├── infrastructure/           # CAPA DE INFRAESTRUCTURA (Adapters)
│   │   ├── adapters/
│   │   │   └── postgres/         # Adaptadores PostgreSQL
│   │   │       ├── postgres_agent_repository.py
│   │   │       ├── postgres_corpus_repository.py
│   │   │       └── postgres_group_mapping_repository.py
│   │   ├── tools/                # Herramientas para agentes
│   │   │   ├── rag_tool.py       # Herramienta RAG con Vertex AI
│   │   │   ├── sample_tools.py   # Herramientas de ejemplo
│   │   │   ├── tool_registry.py  # Registro dinámico de herramientas
│   │   │   └── metadata_fetcher.py # Fetcher metadatos SharePoint/GCS
│   │   └── callbacks/            # Callbacks para ADK
│   │       └── context_management.py # Gestión contexto LLM
│   │
│   ├── services/                 # SERVICIOS DE INTEGRACIÓN
│   │   ├── teams_integration.py  # Integración completa Teams + Azure AD
│   │   ├── azure_ad_router.py    # Router basado en grupos AD
│   │   └── document_service.py   # Procesamiento PDF/DOCX
│   │
│   └── main.py                   # Entry point FastAPI
│
├── migrations/                   # Scripts de base de datos
│   ├── 001_init.sql              # Schema inicial completo
│   ├── 002_remove_area_type_constraint.sql
│   ├── 003_azure_ad_group_mappings.sql
│   ├── 004_fix_sessions_for_adk.sql
│   ├── 005_fix_events_table_for_adk.sql
│   └── 006_assign_rag_to_default_agent.sql
│
├── teams/                        # Microsoft Teams App Package
│   ├── manifest.json             # Teams app manifest
│   ├── color.png                 # App icon (192x192)
│   ├── outline.png               # App outline icon (32x32)
│   └── TeamsApp.zip              # Packaged app para despliegue
│
├── deploy-config.sh              # Configuración de despliegue
├── deploy-complete.sh            # Script despliegue completo GCP
├── docker-compose.yml            # Desarrollo local
├── Dockerfile                    # Imagen de producción
├── requirements.txt              # Dependencias Python
└── README.md                     # Documentación
```

---

## **9. Modelo de Datos y Relaciones**

### 🎯 **9.1. Esquema Conceptual de Relaciones**

```sql
-- =============================================
-- ENTIDADES PRINCIPALES Y SUS RELACIONES
-- =============================================

-- 1. AGENTES: Entidades conversacionales IA
CREATE TABLE agents (
    agent_id VARCHAR(255) PRIMARY KEY,
    name VARCHAR(255) UNIQUE,                    -- Nombre identificativo
    area_type VARCHAR(50),                       -- Área de especialización
    model_name VARCHAR(100),                     -- Modelo LLM
    instruction TEXT,                            -- Personalidad/comportamiento
    description TEXT,                            -- Descripción funcional
    enabled BOOLEAN DEFAULT TRUE
);

-- 2. CORPUS: Bases de conocimiento vectorizadas
CREATE TABLE corpuses (
    corpus_id VARCHAR(255) PRIMARY KEY,
    corpus_name VARCHAR(255) UNIQUE,             -- Identificador técnico
    display_name VARCHAR(255),                   -- Nombre amigable
    vertex_corpus_name VARCHAR(500),             -- Resource name en Vertex AI
    embedding_model VARCHAR(100),                -- Modelo para embeddings
    vector_db_type VARCHAR(50),                  -- Tipo de BD vectorial
    enabled BOOLEAN DEFAULT TRUE
);

-- 3. HERRAMIENTAS: Funcionalidades de los agentes
CREATE TABLE tools (
    tool_id VARCHAR(255) PRIMARY KEY,
    tool_name VARCHAR(255) UNIQUE,
    tool_type VARCHAR(50),                       -- 'rag', 'function', 'agent'
    function_name VARCHAR(255),                  -- Función Python a ejecutar
    parameters JSONB DEFAULT '{}',               -- Configuración específica
    enabled BOOLEAN DEFAULT TRUE
);

-- 4. MAPPINGS AZURE AD: Relación grupos → area_type
CREATE TABLE azure_ad_group_mappings (
    mapping_id SERIAL PRIMARY KEY,
    group_name VARCHAR(255) UNIQUE,              -- Nombre del grupo en Azure AD
    area_type VARCHAR(50),                       -- area_type del agente
    weight INTEGER DEFAULT 0,                    -- Prioridad
    enabled BOOLEAN DEFAULT TRUE
);

-- =============================================
-- RELACIONES MUCHOS A MUCHOS
-- =============================================

-- Agentes ↔ Herramientas (N:M)
CREATE TABLE agent_tools (
    agent_id VARCHAR(255) REFERENCES agents(agent_id),
    tool_id VARCHAR(255) REFERENCES tools(tool_id),
    PRIMARY KEY (agent_id, tool_id)
);

-- Agentes ↔ Corpus (N:M con prioridad)
CREATE TABLE agent_corpuses (
    agent_id VARCHAR(255) REFERENCES agents(agent_id),
    corpus_id VARCHAR(255) REFERENCES corpuses(corpus_id),
    priority INTEGER DEFAULT 1,                 -- 1=principal, 2=secundario
    PRIMARY KEY (agent_id, corpus_id)
);

-- Agentes ↔ Sub-Agentes (N:M jerárquica)
CREATE TABLE agent_sub_agents (
    parent_agent_id VARCHAR(255) REFERENCES agents(agent_id),
    sub_agent_id VARCHAR(255) REFERENCES agents(agent_id),
    PRIMARY KEY (parent_agent_id, sub_agent_id)
);
```

### 🔄 **9.2. Flujos de Mapeo**

#### **Usuario → Agente (via Azure AD Groups)**

```python
# Ejemplo de flujo:
user_groups = ["Legal-Users", "All-Employees"]

# Buscar mappings en BD
mappings = [
    {"group_name": "Legal-Users", "area_type": "legal", "weight": 900},
    {"group_name": "All-Employees", "area_type": "general", "weight": 100}
]

# Seleccionar el de mayor weight
selected_area = "legal"  # weight=900 > weight=100

# Buscar agente con area_type="legal"
agent = Agent.find_by_area_type("legal")  # → "Legal Advisor"
```

#### **Agente → Corpus (N:M con prioridad)**

```sql
-- Ejemplo: Agente Legal tiene acceso a múltiples corpus
SELECT 
    a.name as agent_name,
    c.display_name as corpus_name,
    ac.priority
FROM agents a
JOIN agent_corpuses ac ON a.agent_id = ac.agent_id
JOIN corpuses c ON ac.corpus_id = c.corpus_id
WHERE a.area_type = 'legal'
ORDER BY ac.priority;

-- Resultado:
-- Legal Advisor | Legal Documents     | 1
-- Legal Advisor | HR Policies        | 2  
-- Legal Advisor | General Knowledge  | 3
```

---

## **10. Despliegue y Administración**

### 🚀 **11.1. Script de Despliegue Completo**

**Archivo: `deploy-config.sh`**

```bash
#!/bin/bash

# ==========================================
# PROJECT CONFIGURATION
# ==========================================
export PROJECT_ID="delfosti-grupodc-polidc-dev"
export REGION="us-east4"
export SERVICE_NAME="adk-agent-service"

# ==========================================
# DATABASE CONFIGURATION
# ==========================================
export DB_INSTANCE_NAME="adk-agent-db"
export DB_NAME="adk_agent"
export DB_USER="adk_app"
export DB_ROOT_PASSWORD="$(openssl rand -base64 32)"
export DB_APP_PASSWORD="$(openssl rand -base64 32)"

# ==========================================
# MICROSOFT GRAPH API CONFIGURATION
# ==========================================
export GRAPH_TENANT_ID="44a78b44-3fba-4ad7-b951-6bbdc7b98cdb"
export GRAPH_CLIENT_ID="0c9cd352-368b-4b96-b1b5-780d85a724b4"
export GRAPH_CLIENT_SECRET="fJD8Q~sbgibbi7FRaByL~WDa1hk5M1w5zP4eYcoI"

echo "✅ Configuration loaded successfully"
```

**Archivo: `deploy-complete.sh`**

```bash
#!/bin/bash
set -e  # Exit on error

# Load configuration
source deploy-config.sh

echo "======================================"
echo "🚀 ADK Agent Service Deployment"
echo "======================================"
echo "Project: $PROJECT_ID"
echo "Region: $REGION"
echo "Service: $SERVICE_NAME"
echo "======================================"

# ==========================================
# STEP 1: Enable Required APIs
# ==========================================
echo ""
echo "📦 Step 1: Enabling required APIs..."
gcloud services enable \
  sqladmin.googleapis.com \
  cloudbuild.googleapis.com \
  run.googleapis.com \
  containerregistry.googleapis.com \
  secretmanager.googleapis.com \
  aiplatform.googleapis.com \
  discoveryengine.googleapis.com

echo "✅ APIs enabled"

# ==========================================
# STEP 2: Create Cloud SQL Instance
# ==========================================
echo ""
echo "🗄️  Step 2: Creating Cloud SQL instance..."

if gcloud sql instances describe $DB_INSTANCE_NAME &>/dev/null; then
  echo "⚠️  Cloud SQL instance already exists, skipping creation"
else
  gcloud sql instances create $DB_INSTANCE_NAME \
    --database-version=POSTGRES_16 \
    --tier=db-custom-1-3840 \
    --region=$REGION \
    --root-password="$DB_ROOT_PASSWORD" \
    --storage-auto-increase \
    --storage-size=10GB \
    --backup-start-time=03:00 \
    --no-assign-ip
  
  echo "✅ Cloud SQL instance created"
fi

# ==========================================
# STEP 3: Configure Database
# ==========================================
echo ""
echo "⚙️  Step 3: Configuring database..."

# Create database
gcloud sql databases create $DB_NAME --instance=$DB_INSTANCE_NAME 2>/dev/null || echo "Database already exists"

# Create application user
gcloud sql users create $DB_USER \
  --instance=$DB_INSTANCE_NAME \
  --password="$DB_APP_PASSWORD" 2>/dev/null || \
gcloud sql users set-password $DB_USER \
  --instance=$DB_INSTANCE_NAME \
  --password="$DB_APP_PASSWORD"

echo "✅ Database configured"

# ==========================================
# STEP 4: Create Secrets
# ==========================================
echo ""
echo "🔒 Step 4: Creating secrets..."

# Database password secret
if gcloud secrets describe db-password &>/dev/null; then
  echo -n "$DB_APP_PASSWORD" | gcloud secrets versions add db-password --data-file=-
else
  echo -n "$DB_APP_PASSWORD" | gcloud secrets create db-password \
    --data-file=- \
    --replication-policy="automatic"
fi

# Microsoft Graph Client Secret
if gcloud secrets describe graph-client-secret &>/dev/null; then
  echo -n "$GRAPH_CLIENT_SECRET" | gcloud secrets versions add graph-client-secret --data-file=-
else
  echo -n "$GRAPH_CLIENT_SECRET" | gcloud secrets create graph-client-secret \
    --data-file=- \
    --replication-policy="automatic"
fi

echo "✅ Secrets configured"

# ==========================================
# STEP 5: Build and Deploy
# ==========================================
echo ""
echo "🏗️  Step 5: Building container..."

gcloud builds submit --tag gcr.io/$PROJECT_ID/$SERVICE_NAME

echo ""
echo "🚀 Step 6: Deploying to Cloud Run..."

export CONNECTION_NAME=$(gcloud sql instances describe $DB_INSTANCE_NAME \
  --format='value(connectionName)')

gcloud run deploy $SERVICE_NAME \
  --image gcr.io/$PROJECT_ID/$SERVICE_NAME \
  --platform managed \
  --region $REGION \
  --allow-unauthenticated \
  --memory 1Gi \
  --cpu 1 \
  --min-instances 1 \
  --max-instances 10 \
  --timeout 300 \
  --add-cloudsql-instances $CONNECTION_NAME \
  --set-env-vars "ENVIRONMENT=production,DB_HOST=/cloudsql/$CONNECTION_NAME,DB_PORT=5432,DB_NAME=$DB_NAME,DB_USER=$DB_USER,GOOGLE_CLOUD_PROJECT=$PROJECT_ID,GOOGLE_GENAI_USE_VERTEXAI=TRUE,PERSIST_SESSIONS=true,GRAPH_TENANT_ID=$GRAPH_TENANT_ID,GRAPH_CLIENT_ID=$GRAPH_CLIENT_ID" \
  --set-secrets "DB_PASSWORD=db-password:latest,GRAPH_CLIENT_SECRET=graph-client-secret:latest"

export SERVICE_URL=$(gcloud run services describe $SERVICE_NAME \
  --region $REGION \
  --format 'value(status.url)')

echo ""
echo "======================================"
echo "🎉 DEPLOYMENT COMPLETE!"
echo "======================================"
echo "Service URL: $SERVICE_URL"
echo "API Docs: $SERVICE_URL/docs"
echo "======================================"
```

### ⚙️ **11.2. Comandos de Administración**

```bash
# === GESTIÓN DE BASE DE DATOS ===

# Conectar a base de datos de producción
./cloud-sql-proxy delfosti-grupodc-polidc-dev:us-east4:adk-agent-db &
PGPASSWORD="$(gcloud secrets versions access latest --secret=db-password)" \
  psql -h 127.0.0.1 -U adk_app -d adk_agent

# Ejecutar migración específica
PGPASSWORD="password" psql -h localhost -U adk_app -d adk_agent \
  -f migrations/003_azure_ad_group_mappings.sql

# === GESTIÓN DE CLOUD RUN ===

# Ver logs en tiempo real
gcloud logging tail "resource.type=cloud_run_revision AND resource.labels.service_name=adk-agent-service" \
  --project delfosti-grupodc-polidc-dev

# Actualizar servicio
gcloud run services update adk-agent-service \
  --region us-east4 \
  --memory 2Gi

# === GESTIÓN DE SECRETS ===

# Actualizar secreto
echo -n "nueva_password" | gcloud secrets versions add db-password --data-file=-

# Ver version actual de secreto
gcloud secrets versions access latest --secret=db-password
```

---

## **11. Monitoreo y Troubleshooting**

### 📊 **11.1. Queries de Monitoreo**

```sql
-- === HEALTH CHECK COMPLETO ===
WITH system_health AS (
    SELECT 
        'agents' as component,
        COUNT(*) as total,
        COUNT(*) FILTER (WHERE enabled = true) as enabled,
        COUNT(*) FILTER (WHERE enabled = false) as disabled
    FROM agents
    
    UNION ALL
    
    SELECT 
        'corpuses' as component,
        COUNT(*) as total,
        COUNT(*) FILTER (WHERE enabled = true) as enabled,
        COUNT(*) FILTER (WHERE enabled = false) as disabled
    FROM corpuses
    
    UNION ALL
    
    SELECT 
        'tools' as component,
        COUNT(*) as total,
        COUNT(*) FILTER (WHERE enabled = true) as enabled,
        COUNT(*) FILTER (WHERE enabled = false) as disabled
    FROM tools
),
recent_activity AS (
    SELECT 
        COUNT(DISTINCT user_id) as active_users_24h,
        COUNT(DISTINCT session_id) as sessions_24h,
        COUNT(*) as events_24h
    FROM events 
    WHERE timestamp > NOW() - INTERVAL '24 hours'
)
SELECT 
    json_build_object(
        'system_components', json_agg(sh.*),
        'activity_24h', ra.*
    ) as health_report
FROM system_health sh, recent_activity ra;

-- === ANÁLISIS DE USO DE AGENTES ===
SELECT 
    a.name as agent_name,
    a.area_type,
    COUNT(DISTINCT s.id) as unique_sessions,
    COUNT(e.id) as total_events,
    AVG(LENGTH(e.content::text)) as avg_response_length,
    MAX(e.timestamp) as last_used
FROM agents a
LEFT JOIN sessions s ON s.app_name = 'agent_' || a.agent_id
LEFT JOIN events e ON e.session_id = s.id 
    AND e.timestamp > NOW() - INTERVAL '30 days'
WHERE a.enabled = true
GROUP BY a.agent_id, a.name, a.area_type
ORDER BY total_events DESC;

-- === DETECCIÓN DE PROBLEMAS ===
-- Agentes sin herramientas
SELECT 'agents_without_tools' as issue, a.name, a.area_type
FROM agents a
LEFT JOIN agent_tools at ON a.agent_id = at.agent_id
WHERE a.enabled = true AND at.agent_id IS NULL

UNION ALL

-- Grupos Azure AD sin agente
SELECT 'groups_without_agent' as issue, aagm.group_name, aagm.area_type
FROM azure_ad_group_mappings aagm
LEFT JOIN agents a ON aagm.area_type = a.area_type AND a.enabled = true
WHERE aagm.enabled = true AND a.agent_id IS NULL;
```

### 🔧 **11.2. Scripts de Diagnóstico**

**Archivo: `diagnose-system.sh`**

```bash
#!/bin/bash

echo "======================================"
echo "🩺 SYSTEM DIAGNOSTICS"
echo "======================================"

# Check Cloud Run service
echo "📊 Cloud Run Service Status:"
gcloud run services describe adk-agent-service \
  --region us-east4 \
  --format='table(status.url,status.conditions[].type,status.conditions[].status)'

echo ""
echo "📈 Recent Traffic (last 1 hour):"
gcloud logging read "resource.type=cloud_run_revision 
  AND resource.labels.service_name=adk-agent-service 
  AND timestamp>=\"$(date -d '1 hour ago' --iso-8601)\"" \
  --limit 10 \
  --format='table(timestamp,severity,textPayload)'

# Check database connectivity
echo ""
echo "🗄️  Database Connectivity:"
./cloud-sql-proxy delfosti-grupodc-polidc-dev:us-east4:adk-agent-db &
PROXY_PID=$!
sleep 3

PGPASSWORD="$(gcloud secrets versions access latest --secret=db-password)" \
  psql -h 127.0.0.1 -U adk_app -d adk_agent \
  -c "SELECT 'Database connection: OK' as status;" 2>/dev/null || \
  echo "❌ Database connection failed"

kill $PROXY_PID 2>/dev/null || true

echo ""
echo "🔐 Secrets Status:"
gcloud secrets list --filter="name:db-password OR name:graph-client-secret" \
  --format='table(name,replicationPolicy.automatic,createTime)'

echo ""
echo "✅ Diagnostics completed"
```

### 📱 **12.3. Alertas Recomendadas**

```yaml
Alertas Google Cloud Monitoring:

1. Error Rate Alert:
   - Metric: Cloud Run request error rate > 5%
   - Duration: 5 minutes
   - Action: Send email + Slack notification

2. Response Time Alert:
   - Metric: Cloud Run response time > 10 seconds
   - Duration: 2 minutes
   - Action: Send email

3. Database Connection Alert:
   - Metric: Cloud SQL connection errors > 3
   - Duration: 1 minute
   - Action: Send immediate notification

4. Memory Usage Alert:
   - Metric: Cloud Run memory usage > 80%
   - Duration: 10 minutes
   - Action: Scale up or investigate

5. Cold Start Alert:
   - Metric: Cloud Run instance starts > 20/hour
   - Action: Consider increasing min-instances
```

---

**Documento fusionado completado**  
**Fecha:** 2025-11-18  
**Versión:** 1.0.0  
**Sistema:** Teams Agent Backend con Azure AD + Google Cloud  
**Estado:** Documentación completa unificada
