"""Main application entry point for Cloud Run."""

import os
import logging
from contextlib import asynccontextmanager

# Configure Vertex AI environment variables BEFORE any imports
if not os.getenv("GOOGLE_GENAI_USE_VERTEXAI"):
    os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = "TRUE"

if not os.getenv("GOOGLE_CLOUD_PROJECT"):
    logger_msg = "WARNING: GOOGLE_CLOUD_PROJECT not set. ADK agents will fail."
    print(logger_msg)

if not os.getenv("GOOGLE_CLOUD_LOCATION"):
    os.environ["GOOGLE_CLOUD_LOCATION"] = "us-east4"
    print(f"INFO: GOOGLE_CLOUD_LOCATION not set, defaulting to us-east4")

if not os.getenv("GOOGLE_API_KEY"):
    # For Vertex AI, we don't need API key, but SDK checks for it
    os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = "TRUE"

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from src.application.api import router
from src.application.api.teams_routes import router as teams_router
from src.application.api.group_mapping_routes import router as group_mapping_router
from src.application.di import get_container, close_container


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager."""
    # Startup
    logger.info("🚀 Starting application...")
    try:
        container = get_container()
        await container.init_repository()
        logger.info("✅ Application started successfully")
        logger.info("📄 File processing: Gemini Native (PDF/DOCX)")
    except Exception as e:
        logger.error(f"❌ Error during startup: {e}")
        raise

    yield

    # Shutdown
    logger.info("🛑 Shutting down application...")
    try:
        await close_container()
        logger.info("✅ Application shut down successfully")
    except Exception as e:
        logger.error(f"❌ Error during shutdown: {e}")


# Create FastAPI application
app = FastAPI(
    title="GrupoDC Agent Service",
    description="Google ADK Agent Service with PDF/DOCX support",
    version="1.0.1",
    lifespan=lifespan,
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routes
app.include_router(router, prefix="/api/v1")
app.include_router(teams_router, prefix="/api/v1", tags=["teams"])
app.include_router(group_mapping_router, prefix="/api/v1", tags=["group-mappings"])


@app.get("/")
async def root():
    """Root endpoint."""
    return {
        "message": "GrupoDC Agent Service",
        "version": "1.0.1",
        "features": ["PDF support", "DOCX support", "Gemini 2.5 Flash"],
        "docs": "/docs",
    }


@app.get("/health")
async def health():
    """Health check."""
    return {
        "status": "healthy",
        "version": "1.0.1",
        "file_support": {
            "pdf": True,
            "docx": True,
            "method": "gemini_native"
        }
    }


if __name__ == "__main__":
    import uvicorn

    port = int(os.getenv("PORT", "8080"))
    host = os.getenv("HOST", "0.0.0.0")

    logger.info(f"🚀 Starting server on {host}:{port}")

    uvicorn.run(
        "src.main:app",
        host=host,
        port=port,
        reload=os.getenv("ENVIRONMENT") == "development",
        log_level="info",
    )
