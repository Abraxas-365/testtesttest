"""ADK Agent Service with PostgreSQL configuration."""

__version__ = "1.0.0"
