#!/bin/bash
set -e

# Load configuration
source deploy-config.sh

echo "======================================"
echo "🔧 Fixing Sessions Schema for ADK"
echo "======================================"
echo ""
echo "⚠️  WARNING: This will DROP existing sessions and events tables!"
echo "⚠️  All conversation history will be LOST!"
echo ""
read -p "Are you sure you want to continue? (type 'yes' to proceed): " confirm

if [ "$confirm" != "yes" ]; then
    echo "❌ Migration cancelled"
    exit 0
fi

echo ""
echo "Getting connection details..."
export CONNECTION_NAME=$(gcloud sql instances describe $DB_INSTANCE_NAME \
  --format='value(connectionName)')

# Kill existing proxy
pkill -f cloud-sql-proxy 2>/dev/null || true
sleep 2

# Start proxy
echo "🔌 Starting Cloud SQL Proxy..."
./cloud-sql-proxy $CONNECTION_NAME --port 5432 &
PROXY_PID=$!
sleep 5

cleanup() {
  echo ""
  echo "🧹 Cleaning up..."
  kill $PROXY_PID 2>/dev/null || true
  exit ${1:-0}
}

trap cleanup EXIT INT TERM

# Test connection
echo ""
echo "🔍 Testing database connection..."
if ! PGPASSWORD="$DB_APP_PASSWORD" psql -h 127.0.0.1 -p 5432 -U $DB_USER -d $DB_NAME -c "SELECT 1;" > /dev/null 2>&1; then
  echo "❌ Database connection failed"
  cleanup 1
fi

echo "✅ Connected to database"
echo ""

# Apply migration
echo "🚀 Applying migration..."
echo "──────────────────────────────────────"

if [ -f "004_fix_sessions_for_adk.sql" ]; then
    MIGRATION_FILE="004_fix_sessions_for_adk.sql"
elif [ -f "migrations/004_fix_sessions_for_adk.sql" ]; then
    MIGRATION_FILE="migrations/004_fix_sessions_for_adk.sql"
else
    echo "❌ Migration file not found!"
    echo "Please ensure 004_fix_sessions_for_adk.sql is in current directory or migrations/"
    cleanup 1
fi

echo "📄 Using migration file: $MIGRATION_FILE"
echo ""

PGPASSWORD="$DB_APP_PASSWORD" psql -h 127.0.0.1 -p 5432 -U $DB_USER -d $DB_NAME \
  -f "$MIGRATION_FILE"

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Migration completed successfully!"
    echo ""
    
    # Verify the schema
    echo "🔍 Verifying schema..."
    echo ""
    PGPASSWORD="$DB_APP_PASSWORD" psql -h 127.0.0.1 -p 5432 -U $DB_USER -d $DB_NAME <<'EOSQL'
\echo '=== Sessions Table Schema ==='
SELECT 
    column_name, 
    data_type, 
    is_nullable,
    column_default
FROM information_schema.columns 
WHERE table_name = 'sessions' 
ORDER BY ordinal_position;

\echo ''
\echo '=== Events Table Schema ==='
SELECT 
    column_name, 
    data_type, 
    is_nullable
FROM information_schema.columns 
WHERE table_name = 'events' 
ORDER BY ordinal_position;

\echo ''
\echo '=== Foreign Key Constraints ==='
SELECT
    tc.constraint_name,
    tc.table_name,
    kcu.column_name,
    ccu.table_name AS foreign_table_name,
    ccu.column_name AS foreign_column_name
FROM information_schema.table_constraints AS tc
JOIN information_schema.key_column_usage AS kcu
    ON tc.constraint_name = kcu.constraint_name
    AND tc.table_schema = kcu.table_schema
JOIN information_schema.constraint_column_usage AS ccu
    ON ccu.constraint_name = tc.constraint_name
    AND ccu.table_schema = tc.table_schema
WHERE tc.constraint_type = 'FOREIGN KEY'
    AND tc.table_name IN ('events');

\echo ''
\echo '=== Indexes on Sessions ==='
SELECT indexname, indexdef 
FROM pg_indexes 
WHERE tablename = 'sessions';

\echo ''
\echo '=== Indexes on Events ==='
SELECT indexname, indexdef 
FROM pg_indexes 
WHERE tablename = 'events';
EOSQL
    
    echo ""
    echo "======================================"
    echo "✅ Sessions schema is now ADK-compatible!"
    echo "======================================"
    echo ""
    echo "Schema details:"
    echo "  ✓ sessions.id (VARCHAR) - unique session identifier"
    echo "  ✓ sessions.state (JSONB) - conversation state"
    echo "  ✓ events.id (VARCHAR) - event identifier"
    echo "  ✓ events.content (JSONB) - message content"
    echo ""
    echo "Next steps:"
    echo "1. Remove custom session service:"
    echo "   rm src/infrastructure/adapters/postgres/postgres_session_service.py"
    echo ""
    echo "2. Update __init__.py:"
    echo "   Edit src/infrastructure/adapters/postgres/__init__.py"
    echo "   Remove PostgresSessionService from imports"
    echo ""
    echo "3. Redeploy your service:"
    echo "   ./redeploy.sh"
    echo ""
    echo "4. Test Teams integration:"
    echo "   Send a message in Teams"
    echo ""
    
else
    echo ""
    echo "❌ Migration failed!"
    echo ""
    cleanup 1
fi

cleanup 0
