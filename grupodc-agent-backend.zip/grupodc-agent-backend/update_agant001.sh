#!/bin/bash
set -e

# Cargar configuración desde un archivo externo.
# Asegúrate de que este archivo contenga:
# DB_INSTANCE_NAME="tu-instancia-sql"
# DB_USER="tu-usuario"
# DB_APP_PASSWORD="tu-contraseña"
# DB_NAME="tu-base-de-datos"
source deploy-config.sh

echo "======================================================="
echo "  Actualizando Modelo de agent-001 a gemini-2.5-pro   "
echo "======================================================="
echo ""
echo "Este script actualizará el modelo del agente GPTO"
echo "de gemini-2.5-flash a gemini-2.5-pro"
echo ""

echo "Obteniendo detalles de conexión..."
export CONNECTION_NAME=$(gcloud sql instances describe $DB_INSTANCE_NAME \
  --format='value(connectionName)')

# Matar procesos de proxy existentes para evitar conflictos
pkill -f cloud-sql-proxy 2>/dev/null || true
sleep 2

# Iniciar el proxy en segundo plano
echo "Iniciando Cloud SQL Proxy..."
./cloud-sql-proxy $CONNECTION_NAME --port 5432 &
PROXY_PID=$!
sleep 5

# Función de limpieza para detener el proxy al salir
cleanup() {
  echo ""
  echo "Limpiando y deteniendo el proxy..."
  kill $PROXY_PID 2>/dev/null || true
  exit ${1:-0}
}

trap cleanup EXIT INT TERM

# Probar la conexión a la base de datos
echo ""
echo "Probando la conexión con la base de datos..."
if ! PGPASSWORD="$DB_APP_PASSWORD" psql -h 127.0.0.1 -p 5432 -U $DB_USER -d $DB_NAME -c "SELECT 1;" > /dev/null 2>&1; then
  echo "ERROR: Falló la conexión con la base de datos. Verifica tus credenciales y la configuración del proxy."
  cleanup 1
fi

echo "OK: Conectado a la base de datos."
echo ""

# Mostrar la configuración actual del agente antes del cambio
echo "Configuración actual para agent-001:"
echo "------------------------------------------------------------"
PGPASSWORD="$DB_APP_PASSWORD" psql -h 127.0.0.1 -p 5432 -U $DB_USER -d $DB_NAME \
  -t -c "SELECT 'Agent ID: ' || agent_id || E'\nNombre: ' || name || E'\nModelo: ' || model_name || E'\nTemperature: ' || temperature || E'\nTipo: ' || agent_type FROM agents WHERE agent_id = 'agent-001';"
echo ""

read -p "¿Deseas actualizar el modelo a gemini-2.5-pro? (escribe 'yes' para proceder): " confirm

if [ "$confirm" != "yes" ]; then
    echo "Actualización cancelada por el usuario."
    cleanup 0
fi

# Aplicar la actualización del modelo
echo ""
echo "Actualizando agent-001 a gemini-2.5-pro..."
echo "------------------------------------------------------------"

PGPASSWORD="$DB_APP_PASSWORD" psql -h 127.0.0.1 -p 5432 -U $DB_USER -d $DB_NAME <<'EOSQL'

-- Actualizar solo agent-001 a gemini-2.5-pro
UPDATE agents
SET 
    model_name = 'gemini-2.5-pro',
    updated_at = NOW()
WHERE agent_id = 'agent-001';

-- Mostrar la configuración actualizada para verificar el cambio
SELECT 
    agent_id,
    name,
    model_name,
    temperature,
    agent_type,
    area_type,
    updated_at
FROM agents 
WHERE agent_id = 'agent-001';

EOSQL

if [ $? -eq 0 ]; then
    echo ""
    echo "=========================================================================="
    echo " ✅ ¡ÉXITO! agent-001 actualizado a gemini-2.5-pro                       "
    echo "=========================================================================="
    echo ""
    echo "Cambios aplicados:"
    echo "  🤖 **Modelo actualizado:** gemini-2.5-pro"
    echo "  🎯 **Agent ID:** agent-001 (search_assistant)"
    echo ""
    echo "Beneficios esperados:"
    echo "  📊 Mayor capacidad de razonamiento"
    echo "  🧠 Mejor comprensión de contextos complejos"
    echo "  ✨ Respuestas más precisas y detalladas"
    echo "  📋 Mejor generación de tablas comparativas"
    echo ""
else
    echo ""
    echo "❌ ERROR: ¡La actualización de la base de datos falló! Revisa el log."
    echo ""
    cleanup 1
fi

cleanup
