#!/bin/bash
export PROJECT_ID="delfosti-grupodc-polidc-dev"
export REGION="us-east4"
export SERVICE_NAME="grupodc-agent-backend-dev"
export DB_INSTANCE_NAME="grupodc-agent-db-dev"
export DB_NAME="grupodc_agents_db"
export DB_USER="grupodc_app_user"
export PERSIST_SESSIONS=true  

# Database passwords
export DB_ROOT_PASSWORD="k<F~\">74N0Nuok-r"
export DB_APP_PASSWORD="nOQLgajsMO0QaACcznSGzE8NouacdUAT<"

# Microsoft Graph API credentials (Azure AD App Registration)
export GRAPH_TENANT_ID="bb169637-b6a9-4ba0-bf9c-ea27f730e970"
export GRAPH_CLIENT_ID="8f932a37-a7f6-4fe8-be5e-a72ab69758cf"
export GRAPH_CLIENT_SECRET="I4r8Q~oVLSEse_WIf.WScGLN4MaHE3K16Xbhudxp"

echo "✅ Configuration loaded"
echo "   Project: $PROJECT_ID"
echo "   Region: $REGION"
echo "   Service: $SERVICE_NAME"
echo "   Graph Tenant: $GRAPH_TENANT_ID"


