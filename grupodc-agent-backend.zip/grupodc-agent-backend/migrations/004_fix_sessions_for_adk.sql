BEGIN;

-- Drop dependent objects
DROP TRIGGER IF EXISTS trigger_update_session_last_message ON messages CASCADE;
DROP FUNCTION IF EXISTS update_session_last_message() CASCADE;

-- Drop all tables
DROP TABLE IF EXISTS messages CASCADE;
DROP TABLE IF EXISTS events CASCADE;
DROP TABLE IF EXISTS user_states CASCADE;
DROP TABLE IF EXISTS app_states CASCADE;
DROP TABLE IF EXISTS sessions CASCADE;

-- ============================================
-- Create ADK-compatible sessions table
-- ============================================
CREATE TABLE sessions (
    app_name VARCHAR(255) NOT NULL,
    user_id VARCHAR(255) NOT NULL,
    id VARCHAR(255) NOT NULL,
    
    state JSONB DEFAULT '{}'::jsonb NOT NULL,
    
    -- ADK requires BOTH create_time AND update_time
    create_time TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    update_time TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    
    PRIMARY KEY (app_name, user_id, id),
    UNIQUE (id)
);

CREATE INDEX idx_sessions_app_name ON sessions(app_name);
CREATE INDEX idx_sessions_user_id ON sessions(user_id);
CREATE INDEX idx_sessions_app_user ON sessions(app_name, user_id);
CREATE INDEX idx_sessions_update_time ON sessions(update_time);

-- ============================================
-- Create app_states table
-- ============================================
CREATE TABLE app_states (
    app_name VARCHAR(255) PRIMARY KEY,
    state JSONB DEFAULT '{}'::jsonb NOT NULL,
    create_time TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    update_time TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- ============================================
-- Create user_states table
-- ============================================
CREATE TABLE user_states (
    app_name VARCHAR(255) NOT NULL,
    user_id VARCHAR(255) NOT NULL,
    state JSONB DEFAULT '{}'::jsonb NOT NULL,
    create_time TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    update_time TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    PRIMARY KEY (app_name, user_id)
);

CREATE INDEX idx_user_states_user_id ON user_states(user_id);

-- ============================================
-- Create events table (ADK-compatible)
-- ============================================
CREATE TABLE events (
    -- ⚠️ CRITICAL: id must be VARCHAR, not SERIAL
    id VARCHAR(255) PRIMARY KEY,
    
    -- Session identification
    app_name VARCHAR(255) NOT NULL,
    user_id VARCHAR(255) NOT NULL,
    session_id VARCHAR(255) NOT NULL,
    
    -- Event metadata
    invocation_id VARCHAR(255),
    author VARCHAR(255),
    branch VARCHAR(255),
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
    
    -- Event data (ADK stores these as JSONB/BYTEA)
    content JSONB,
    actions BYTEA,
    long_running_tool_ids_json TEXT,
    grounding_metadata JSONB,
    
    -- Event flags
    partial BOOLEAN,
    turn_complete BOOLEAN,
    error_code VARCHAR(255),
    error_message TEXT,
    interrupted BOOLEAN,
    
    FOREIGN KEY (app_name, user_id, session_id) 
        REFERENCES sessions(app_name, user_id, id) 
        ON DELETE CASCADE
);

CREATE INDEX idx_events_session ON events(app_name, user_id, session_id);
CREATE INDEX idx_events_timestamp ON events(timestamp);
CREATE INDEX idx_events_author ON events(author);
CREATE INDEX idx_events_invocation_id ON events(invocation_id);
CREATE INDEX idx_events_turn_complete ON events(turn_complete);

COMMIT;
