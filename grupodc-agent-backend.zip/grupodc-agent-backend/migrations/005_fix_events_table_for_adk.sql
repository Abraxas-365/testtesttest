-- Fix events table schema for ADK compatibility
BEGIN;

-- Step 1: Drop dependent foreign key constraint (if exists)
ALTER TABLE messages DROP CONSTRAINT IF EXISTS fk_messages_session CASCADE;

-- Step 2: Drop the existing events table and recreate with correct schema
DROP TABLE IF EXISTS events CASCADE;

-- Step 3: Create events table matching ADK's expectations
CREATE TABLE events (
    -- ✅ CRITICAL: id must be VARCHAR, not SERIAL
    id VARCHAR(255) PRIMARY KEY,  -- ADK generates string IDs like "hQ2N32eV"
    
    -- Session identification (composite foreign key)
    app_name VARCHAR(255) NOT NULL,
    user_id VARCHAR(255) NOT NULL,
    session_id VARCHAR(255) NOT NULL,
    
    -- Event metadata
    invocation_id VARCHAR(255),
    author VARCHAR(255),
    branch VARCHAR(255),
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
    
    -- Event data (ADK uses JSONB for these)
    content JSONB,
    actions BYTEA,  -- ADK stores EventActions as pickled binary
    long_running_tool_ids_json TEXT,
    grounding_metadata JSONB,
    
    -- Event flags
    partial BOOLEAN,
    turn_complete BOOLEAN,
    error_code VARCHAR(255),
    error_message TEXT,
    interrupted BOOLEAN,
    
    -- Foreign key to sessions table
    FOREIGN KEY (app_name, user_id, session_id) 
        REFERENCES sessions(app_name, user_id, id) 
        ON DELETE CASCADE
);

-- Step 4: Create indexes for performance
CREATE INDEX idx_events_session ON events(app_name, user_id, session_id);
CREATE INDEX idx_events_timestamp ON events(timestamp);
CREATE INDEX idx_events_author ON events(author);
CREATE INDEX idx_events_invocation_id ON events(invocation_id);
CREATE INDEX idx_events_turn_complete ON events(turn_complete);

COMMIT;

