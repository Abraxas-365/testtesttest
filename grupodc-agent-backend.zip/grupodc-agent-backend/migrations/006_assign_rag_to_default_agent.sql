BEGIN;

-- Step 1: Ensure RAG tool exists
INSERT INTO tools (tool_id, tool_name, tool_type, function_name, description, enabled)
VALUES (
    'tool-004',
    'rag_search',
    'rag',
    'vertex_rag_retrieval',
    'Retrieve information from RAG corpus using Vertex AI RAG Engine',
    TRUE
)
ON CONFLICT (tool_id) DO UPDATE SET
    tool_name = EXCLUDED.tool_name,
    description = EXCLUDED.description,
    enabled = TRUE;

-- Step 2: REMOVE ALL existing tools from agent-001
DELETE FROM agent_tools WHERE agent_id = 'agent-001';

-- Step 3: Assign ONLY the RAG tool to agent-001
INSERT INTO agent_tools (agent_id, tool_id)
VALUES ('agent-001', 'tool-004');

-- Step 4: Create/update corpus entry with your actual Vertex AI RAG corpus
INSERT INTO corpuses (
    corpus_id,
    corpus_name,
    display_name,
    description,
    vertex_corpus_name,
    embedding_model,
    vector_db_type,
    enabled
)
VALUES (
    'corpus-sharepoint',
    'grupodc_sharepoint_rag',
    'GrupoDC SharePoint RAG Corpus',
    'Corpus principal donde se indexan los documentos de SharePoint',
    'projects/delfosti-grupodc-polidc-dev/locations/us-east4/ragCorpora/4611686018427387904',
    'text-multilingual-embedding-002',
    'vertex_rag',
    TRUE
)
ON CONFLICT (corpus_id) DO UPDATE SET
    vertex_corpus_name = 'projects/delfosti-grupodc-polidc-dev/locations/us-east4/ragCorpora/4611686018427387904',
    embedding_model = 'text-multilingual-embedding-002',
    enabled = TRUE,
    updated_at = NOW();

-- Step 5: Assign corpus to agent-001 with priority 1
INSERT INTO agent_corpuses (agent_id, corpus_id, priority)
VALUES ('agent-001', 'corpus-sharepoint', 1)
ON CONFLICT (agent_id, corpus_id) DO UPDATE SET
    priority = 1;

-- Step 6: Update agent description and instruction
UPDATE agents
SET 
    description = 'Assistant with access ONLY to GrupoDC SharePoint knowledge base via RAG search.',
    instruction = 'You are a helpful assistant with access to the company SharePoint documents. Use the rag_search tool to retrieve relevant information from company documents, policies, and internal information. You can ONLY search the knowledge base - you cannot search the web or access other external tools.',
    updated_at = NOW()
WHERE agent_id = 'agent-001';

COMMIT;

-- Verify the changes
DO $$
DECLARE
    tool_count INTEGER;
    corpus_count INTEGER;
    tool_name TEXT;
BEGIN
    -- Count tools
    SELECT COUNT(*) INTO tool_count FROM agent_tools WHERE agent_id = 'agent-001';
    
    -- Get tool name
    SELECT t.tool_name INTO tool_name 
    FROM agent_tools at 
    JOIN tools t ON at.tool_id = t.tool_id 
    WHERE at.agent_id = 'agent-001';
    
    -- Count corpuses
    SELECT COUNT(*) INTO corpus_count FROM agent_corpuses WHERE agent_id = 'agent-001';
    
    RAISE NOTICE '========================================';
    RAISE NOTICE 'Migration 006 Complete!';
    RAISE NOTICE '========================================';
    RAISE NOTICE 'Agent: search_assistant (agent-001)';
    RAISE NOTICE 'Total tools assigned: %', tool_count;
    RAISE NOTICE 'Tool name: %', tool_name;
    RAISE NOTICE 'Corpuses assigned: %', corpus_count;
    RAISE NOTICE '----------------------------------------';
    RAISE NOTICE 'RAG Configuration:';
    RAISE NOTICE '  - Corpus: grupodc-sharepoint-rag-corpus-dev';
    RAISE NOTICE '  - Embedding: text-multilingual-embedding-002';
    RAISE NOTICE '  - Region: us-east4';
    RAISE NOTICE '  - Vector DB: RagManaged';
    RAISE NOTICE '========================================';
    
    -- Warn if unexpected configuration
    IF tool_count != 1 THEN
        RAISE WARNING 'Expected 1 tool, found %', tool_count;
    END IF;
    
    IF tool_name != 'rag_search' THEN
        RAISE WARNING 'Expected rag_search tool, found %', tool_name;
    END IF;
END $$;
