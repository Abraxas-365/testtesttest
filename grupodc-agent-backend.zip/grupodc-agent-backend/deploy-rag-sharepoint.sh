#!/bin/bash
set -e  # Exit on error

# ==========================================
# RAG Engine Configuration
# ==========================================

# GCP Configuration
PROJECT_ID="delfosti-grupodc-polidc-dev"
PROJECT_NUMBER="118078450167"
REGION="us-east4"
CORPUS_NAME="marinasol-sharepoint-corpus"
CORPUS_DISPLAY_NAME="Marinasol SharePoint Knowledge Base"

# Document AI Layout Parser
DOCAI_PROCESSOR_NAME="projects/118078450167/locations/us/processors/49d157db0ee0c3a9"
DOCAI_REGION="us"

# Embedding Model Configuration
EMBEDDING_MODEL="text-multilingual-embedding-002"
EMBEDDING_MODEL_VERSION="002"

# SharePoint Configuration
SHAREPOINT_TENANT_ID="44a78b44-3fba-4ad7-b951-6bbdc7b98cdb"
SHAREPOINT_CLIENT_ID="0c9cd352-368b-4b96-b1b5-780d85a724b4"
SHAREPOINT_CLIENT_SECRET="fJD8Q~sbgibbi7FRaByL~WDa1hk5M1w5zP4eYcoI"
SHAREPOINT_SITE_NAME="delfostipe.sharepoint.com,a1be7e65-9ecd-42ba-9abd-7e0e5f2eddcb,536c033d-5197-4e0c-955d-20e63ad77290"
SHAREPOINT_DRIVE_NAME="Documents"

# SharePoint Folder Paths
FOLDER_CORPORATIVOS="/sites/TeamDesarrollo2-Proyectos/Documentos compartidos/Proyectos/Grupo DC/Base de datos/Corporativos"
FOLDER_DC_INMOBILIARIO="/sites/TeamDesarrollo2-Proyectos/Documentos compartidos/Proyectos/Grupo DC/Base de datos/DC Grupo Inmobiliario"
FOLDER_MARINASOL="/sites/TeamDesarrollo2-Proyectos/Documentos compartidos/Proyectos/Grupo DC/Base de datos/Marinasol"
FOLDER_OCP="/sites/TeamDesarrollo2-Proyectos/Documentos compartidos/Proyectos/Grupo DC/Base de datos/OCP"

# RAG Configuration
CHUNK_SIZE=1024
CHUNK_OVERLAP=256
REFRESH_INTERVAL=300  # Sync every 5 minutes (300 seconds)
MAX_PARSING_REQUESTS=1000
SIMILARITY_TOP_K=10
VECTOR_DISTANCE_THRESHOLD=0.5

# ==========================================
# START DEPLOYMENT
# ==========================================

echo "======================================"
echo "🚀 RAG Engine + SharePoint Deployment"
echo "======================================"
echo "Project: $PROJECT_ID"
echo "Region: $REGION"
echo "Corpus: $CORPUS_DISPLAY_NAME"
echo "Embedding: $EMBEDDING_MODEL"
echo "Document AI: $DOCAI_PROCESSOR_NAME"
echo "======================================"

# ==========================================
# STEP 1: Enable Required APIs
# ==========================================
echo ""
echo "📦 Step 1: Enabling required APIs..."
gcloud services enable \
  aiplatform.googleapis.com \
  documentai.googleapis.com \
  secretmanager.googleapis.com \
  storage.googleapis.com \
  spanner.googleapis.com \
  --project=$PROJECT_ID

echo "✅ APIs enabled"

# ==========================================
# STEP 2: Set IAM Permissions
# ==========================================
echo ""
echo "🔐 Step 2: Setting up IAM permissions..."

COMPUTE_SA="${PROJECT_NUMBER}-compute@developer.gserviceaccount.com"

# Grant Vertex AI permissions
gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="serviceAccount:$COMPUTE_SA" \
  --role="roles/aiplatform.user" \
  --no-user-output-enabled

# Grant Document AI permissions
gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="serviceAccount:$COMPUTE_SA" \
  --role="roles/documentai.apiUser" \
  --no-user-output-enabled

# Grant Secret Manager permissions
gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="serviceAccount:$COMPUTE_SA" \
  --role="roles/secretmanager.secretAccessor" \
  --no-user-output-enabled

echo "✅ IAM permissions set"

# ==========================================
# STEP 3: Create Secrets in Secret Manager
# ==========================================
echo ""
echo "🔑 Step 3: Creating SharePoint secrets..."

# SharePoint Client Secret
if gcloud secrets describe sharepoint-client-secret --project=$PROJECT_ID &>/dev/null; then
  echo "Updating existing sharepoint-client-secret..."
  echo -n "$SHAREPOINT_CLIENT_SECRET" | gcloud secrets versions add sharepoint-client-secret \
    --data-file=- \
    --project=$PROJECT_ID
else
  echo "Creating new sharepoint-client-secret..."
  echo -n "$SHAREPOINT_CLIENT_SECRET" | gcloud secrets create sharepoint-client-secret \
    --data-file=- \
    --replication-policy="automatic" \
    --project=$PROJECT_ID
fi

# Get secret version resource name
SECRET_VERSION=$(gcloud secrets versions describe latest \
  --secret=sharepoint-client-secret \
  --project=$PROJECT_ID \
  --format='value(name)')

echo "✅ Secret created: $SECRET_VERSION"

# ==========================================
# STEP 4: Setup Python Virtual Environment
# ==========================================
echo ""
echo "🐍 Step 4: Setting up Python virtual environment..."

# Check if venv exists, create if not
if [ ! -d "venv" ]; then
  echo "Creating virtual environment..."
  python3 -m venv venv
  echo "✅ Virtual environment created"
else
  echo "✅ Virtual environment already exists"
fi

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate

# Upgrade pip in venv
echo "Upgrading pip..."
pip install --quiet --upgrade pip

# Install required packages in venv
echo "Installing Python dependencies in virtual environment..."
pip install --quiet --upgrade \
  google-cloud-aiplatform \
  vertexai

echo "✅ Python dependencies installed in venv"

# ==========================================
# STEP 5: Deploy RAG Engine with Python
# ==========================================
echo ""
echo "🚀 Step 5: Deploying RAG Engine..."

python3 - <<PYTHON_SCRIPT
import os
import sys
from datetime import datetime
import vertexai
from vertexai.preview import rag
from vertexai.preview.rag.utils import resources

print("="*70)
print("🧠 Initializing Vertex AI RAG Engine")
print("="*70)

# Configuration
PROJECT_ID = "$PROJECT_ID"
REGION = "$REGION"
CORPUS_DISPLAY_NAME = "$CORPUS_DISPLAY_NAME"
DOCAI_PROCESSOR_NAME = "$DOCAI_PROCESSOR_NAME"
SECRET_VERSION = "$SECRET_VERSION"
CHUNK_SIZE = int("$CHUNK_SIZE")
CHUNK_OVERLAP = int("$CHUNK_OVERLAP")
REFRESH_INTERVAL = int("$REFRESH_INTERVAL")
MAX_PARSING_REQUESTS = int("$MAX_PARSING_REQUESTS")
EMBEDDING_MODEL = "$EMBEDDING_MODEL"
SIMILARITY_TOP_K = int("$SIMILARITY_TOP_K")
VECTOR_DISTANCE_THRESHOLD = float("$VECTOR_DISTANCE_THRESHOLD")

# SharePoint Configuration
TENANT_ID = "$SHAREPOINT_TENANT_ID"
CLIENT_ID = "$SHAREPOINT_CLIENT_ID"
SITE_NAME = "$SHAREPOINT_SITE_NAME"
DRIVE_NAME = "$SHAREPOINT_DRIVE_NAME"

# Folder paths
FOLDERS = [
    "$FOLDER_CORPORATIVOS",
    "$FOLDER_DC_INMOBILIARIO",
    "$FOLDER_MARINASOL",
    "$FOLDER_OCP"
]

print(f"📊 Configuration:")
print(f"   Project: {PROJECT_ID}")
print(f"   Region: {REGION}")
print(f"   Embedding Model: {EMBEDDING_MODEL}")
print(f"   Vector Store: RagManaged (Spanner)")
print(f"   SharePoint Site: {SITE_NAME}")
print(f"   Total Folders: {len(FOLDERS)}")

# Initialize Vertex AI
vertexai.init(project=PROJECT_ID, location=REGION)

# ==========================================
# Create RAG Corpus with Text Multilingual Embedding 002
# ==========================================
print(f"\n{'='*70}")
print(f"📚 Creating RAG Corpus: {CORPUS_DISPLAY_NAME}")
print(f"{'='*70}")

try:
    # Create corpus with specific embedding model
    corpus = rag.create_corpus(
        display_name=CORPUS_DISPLAY_NAME,
        description=f"SharePoint knowledge base from {SITE_NAME} with Document AI Layout Parser and {EMBEDDING_MODEL}",
        embedding_model_config=rag.EmbeddingModelConfig(
            publisher_model=f"publishers/google/models/{EMBEDDING_MODEL}"
        )
    )
    print(f"✅ Corpus created successfully")
    print(f"   Name: {corpus.name}")
    print(f"   Display Name: {corpus.display_name}")
    print(f"   Embedding Model: {EMBEDDING_MODEL}")
    
except Exception as e:
    error_str = str(e).lower()
    if "already exists" in error_str or "duplicate" in error_str:
        print("⚠️  Corpus with this name already exists")
        print("   Searching for existing corpus...")
        
        # List all corpora and find matching one
        corpora = rag.list_corpora()
        corpus = None
        for c in corpora:
            if c.display_name == CORPUS_DISPLAY_NAME:
                corpus = c
                break
        
        if corpus:
            print(f"✅ Using existing corpus: {corpus.name}")
        else:
            print("❌ Could not find existing corpus with matching display name")
            print("   Available corpora:")
            for c in corpora:
                print(f"   - {c.display_name}")
            sys.exit(1)
    else:
        print(f"❌ Error creating corpus: {str(e)}")
        sys.exit(1)

corpus_name = corpus.name
print(f"\n📍 Corpus Resource Name:")
print(f"   {corpus_name}")

# ==========================================
# Import files from SharePoint folders
# ==========================================
print(f"\n{'='*70}")
print(f"📥 Importing Documents from SharePoint")
print(f"{'='*70}")
print(f"⏱️  Sync Interval: {REFRESH_INTERVAL} seconds (auto-refresh enabled)")
print(f"🔍 Document AI Layout Parser: Active")
print(f"   Processor: {DOCAI_PROCESSOR_NAME}")
print(f"   Formats: PDF, HTML, DOCX, PPTX, XLSX, XLSM")
print(f"   OCR: Enabled for scanned documents")
print(f"   Max pages: 15 per document")
print(f"   Max size: 20 MB per file")

import_responses = []
total_imported = 0
total_skipped = 0
total_errors = 0

for idx, folder_path in enumerate(FOLDERS, 1):
    print(f"\n{'─'*70}")
    print(f"📂 Folder {idx}/{len(FOLDERS)}")
    print(f"{'─'*70}")
    print(f"Path: {folder_path}")
    
    try:
        # Configure SharePoint source - CORRECTED based on official Google example
        sharepoint_source = resources.SharePointSources(
            share_point_sources=[
                resources.SharePointSource(
                    client_id=CLIENT_ID,
                    client_secret=SECRET_VERSION,  # Direct string - no wrapper needed
                    tenant_id=TENANT_ID,
                    sharepoint_site_name=SITE_NAME,
                    folder_path=folder_path,  # CORRECT: folder_path (singular)
                    drive_name=DRIVE_NAME,
                )
            ]
        )
        
        print(f"🚀 Starting import with Document AI Layout Parser...")
        
        # Import files with Document AI Layout Parser and auto-refresh
        response = rag.import_files(
            corpus_name=corpus_name,
            source=sharepoint_source,
            chunk_size=CHUNK_SIZE,
            chunk_overlap=CHUNK_OVERLAP,
            layout_parser=rag.LayoutParserConfig(
                processor_name=DOCAI_PROCESSOR_NAME,
                max_parsing_requests_per_min=MAX_PARSING_REQUESTS
            ),
            refresh_interval=REFRESH_INTERVAL  # Auto-sync enabled
        )
        
        import_responses.append({
            'folder': folder_path,
            'response': response,
            'status': 'success'
        })
        
        total_imported += response.imported_rag_files_count
        total_skipped += response.skipped_rag_files_count
        
        print(f"✅ Import completed for folder {idx}")
        print(f"   ✓ Imported: {response.imported_rag_files_count} files")
        print(f"   ⭐  Skipped: {response.skipped_rag_files_count} files (no changes)")
        
    except Exception as e:
        total_errors += 1
        error_msg = str(e)
        print(f"❌ Error importing folder {idx}: {error_msg}")
        
        import_responses.append({
            'folder': folder_path,
            'error': error_msg,
            'status': 'failed'
        })

# ==========================================
# Deployment Summary
# ==========================================
print(f"\n{'='*70}")
print("📊 DEPLOYMENT SUMMARY")
print(f"{'='*70}")

print(f"\n✅ RAG Corpus:")
print(f"   Name: {corpus_name}")
print(f"   Display Name: {CORPUS_DISPLAY_NAME}")
print(f"   Embedding Model: {EMBEDDING_MODEL}")
print(f"   Vector Store: RagManaged (Spanner)")

print(f"\n🔗 SharePoint Integration:")
print(f"   Site: {SITE_NAME}")
print(f"   Drive: {DRIVE_NAME}")
print(f"   Total folders: {len(FOLDERS)}")

print(f"\n📈 Import Statistics:")
print(f"   ✓ Successfully imported: {total_imported} files")
print(f"   ⭐️  Skipped (unchanged): {total_skipped} files")
print(f"   ❌ Errors: {total_errors}")

print(f"\n🔄 Auto-Sync:")
print(f"   Status: ENABLED ✅")
print(f"   Interval: {REFRESH_INTERVAL} seconds ({REFRESH_INTERVAL/60:.1f} minutes)")
print(f"   Behavior: Incremental sync with deduplication")

print(f"\n🔍 Document Processing:")
print(f"   Parser: Document AI Layout Parser")
print(f"   Chunk size: {CHUNK_SIZE} tokens")
print(f"   Chunk overlap: {CHUNK_OVERLAP} tokens")
print(f"   OCR: Enabled for scanned PDFs")

# Detailed folder status
print(f"\n📂 Folder Import Status:")
for idx, resp in enumerate(import_responses, 1):
    folder_name = resp['folder'].split('/')[-1]
    status = resp['status']
    
    if status == 'success':
        files = resp['response'].imported_rag_files_count
        skipped = resp['response'].skipped_rag_files_count
        print(f"   {idx}. {folder_name}: ✅ {files} imported, {skipped} skipped")
    else:
        print(f"   {idx}. {folder_name}: ❌ Failed - {resp['error'][:50]}...")

# ==========================================
# Save configuration to file
# ==========================================
config_file = f"rag-corpus-config-{PROJECT_ID}.txt"

with open(config_file, "w") as f:
    f.write("RAG ENGINE CONFIGURATION\n")
    f.write("="*70 + "\n\n")
    
    f.write("CORPUS INFORMATION\n")
    f.write("-"*70 + "\n")
    f.write(f"Resource Name: {corpus_name}\n")
    f.write(f"Display Name: {CORPUS_DISPLAY_NAME}\n")
    f.write(f"Project ID: {PROJECT_ID}\n")
    f.write(f"Region: {REGION}\n")
    f.write(f"Embedding Model: {EMBEDDING_MODEL}\n")
    f.write(f"Vector Store: RagManaged (Spanner)\n\n")
    
    f.write("DOCUMENT AI CONFIGURATION\n")
    f.write("-"*70 + "\n")
    f.write(f"Processor: {DOCAI_PROCESSOR_NAME}\n")
    f.write(f"Supported Formats: PDF, HTML, DOCX, PPTX, XLSX, XLSM\n")
    f.write(f"OCR Enabled: Yes\n")
    f.write(f"Max Pages: 15 per document\n")
    f.write(f"Max Size: 20 MB per file\n\n")
    
    f.write("SHAREPOINT CONFIGURATION\n")
    f.write("-"*70 + "\n")
    f.write(f"Site: {SITE_NAME}\n")
    f.write(f"Drive: {DRIVE_NAME}\n")
    f.write(f"Tenant ID: {TENANT_ID}\n")
    f.write(f"Client ID: {CLIENT_ID}\n")
    f.write(f"Secret: Stored in Secret Manager\n\n")
    
    f.write("FOLDER PATHS\n")
    f.write("-"*70 + "\n")
    for idx, folder in enumerate(FOLDERS, 1):
        f.write(f"{idx}. {folder}\n")
    
    f.write("\nRAG CONFIGURATION\n")
    f.write("-"*70 + "\n")
    f.write(f"Chunk Size: {CHUNK_SIZE} tokens\n")
    f.write(f"Chunk Overlap: {CHUNK_OVERLAP} tokens\n")
    f.write(f"Refresh Interval: {REFRESH_INTERVAL} seconds\n")
    f.write(f"Similarity Top K: {SIMILARITY_TOP_K}\n")
    f.write(f"Distance Threshold: {VECTOR_DISTANCE_THRESHOLD}\n\n")
    
    f.write("IMPORT STATISTICS\n")
    f.write("-"*70 + "\n")
    f.write(f"Total Imported: {total_imported} files\n")
    f.write(f"Total Skipped: {total_skipped} files\n")
    f.write(f"Total Errors: {total_errors}\n\n")
    
    f.write(f"Deployed: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

print(f"\n💾 Configuration saved to: {config_file}")

# ==========================================
# Create test query script
# ==========================================
test_script = "test_rag_query.py"

with open(test_script, "w") as f:
    f.write("""#!/usr/bin/env python3
import vertexai
from vertexai.preview import rag
import sys

# Configuration
PROJECT_ID = "$PROJECT_ID"
REGION = "$REGION"
CORPUS_NAME = "$corpus_name"

vertexai.init(project=PROJECT_ID, location=REGION)

def test_query(query_text):
    print(f"\\n{'='*70}")
    print(f"🔍 Testing RAG Query")
    print(f"{'='*70}")
    print(f"Query: {query_text}")
    print(f"Corpus: {CORPUS_NAME}")
    
    try:
        response = rag.retrieval_query(
            rag_resources=[
                rag.RagResource(
                    rag_corpus=CORPUS_NAME,
                )
            ],
            text=query_text,
            similarity_top_k=5,
        )
        
        print(f"\\n📚 Retrieved {len(response.contexts.contexts)} contexts:\\n")
        
        for idx, context in enumerate(response.contexts.contexts, 1):
            print(f"{idx}. Distance: {context.distance:.4f}")
            print(f"   Source: {context.source_uri}")
            print(f"   Text: {context.text[:150]}...")
            print()
        
        print("✅ Query completed successfully")
        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        query = "¿Cuáles son las políticas de seguridad?"
    else:
        query = " ".join(sys.argv[1:])
    
    test_query(query)
""".replace("$PROJECT_ID", PROJECT_ID)
       .replace("$REGION", REGION)
       .replace("$corpus_name", corpus_name))

import os
os.chmod(test_script, 0o755)

print(f"✅ Test script created: {test_script}")

print(f"\n{'='*70}")
print("🎉 RAG ENGINE DEPLOYMENT COMPLETE!")
print(f"{'='*70}")

PYTHON_SCRIPT

# Deactivate virtual environment
deactivate

echo "✅ Virtual environment deactivated"

# ==========================================
# DEPLOYMENT COMPLETE
# ==========================================
echo ""
echo "======================================"
echo "✨ DEPLOYMENT SUMMARY"
echo "======================================"
echo ""
echo "📚 RAG Corpus:"
echo "   Project: $PROJECT_ID"
echo "   Region: $REGION"
echo "   Display Name: $CORPUS_DISPLAY_NAME"
echo "   Embedding: $EMBEDDING_MODEL (Text Multilingual 002)"
echo "   Vector Store: RagManaged (Spanner)"
echo ""
echo "🔄 Auto-Sync:"
echo "   Status: ENABLED ✅"
echo "   Interval: $REFRESH_INTERVAL seconds"
echo "   Deduplication: Active"
echo ""
echo "🔍 Document AI:"
echo "   Processor: Layout Parser"
echo "   OCR: Enabled for scanned documents"
echo "   Formats: PDF, DOCX, PPTX, XLSX, HTML"
echo ""
echo "🔗 SharePoint:"
echo "   Site: $SHAREPOINT_SITE_NAME"
echo "   Folders: 4 (Corporativos, DC Inmobiliario, Marinasol, OCP)"
echo ""
echo "📁 Configuration Files:"
echo "   - rag-corpus-config-$PROJECT_ID.txt (full configuration)"
echo "   - test_rag_query.py (query testing script)"
echo "   - venv/ (Python virtual environment)"
echo ""
echo "🧪 Test Commands:"
echo ""
echo "# Activate venv first:"
echo "source venv/bin/activate"
echo ""
echo "# Test with default query:"
echo "./test_rag_query.py"
echo ""
echo "# Test with custom query:"
echo "./test_rag_query.py '¿Qué documentos hay sobre Marinasol?'"
echo ""
echo "# Deactivate venv when done:"
echo "deactivate"
echo ""
echo "# View full configuration:"
echo "cat rag-corpus-config-$PROJECT_ID.txt"
echo ""
echo "# Monitor sync status (check logs):"
echo "gcloud logging read 'resource.type=aiplatform.googleapis.com/RagCorpus' \\"
echo "  --project=$PROJECT_ID \\"
echo "  --limit=50 \\"
echo "  --format=json"
echo ""
echo "======================================"
echo "✅ All systems ready!"
echo "======================================"

