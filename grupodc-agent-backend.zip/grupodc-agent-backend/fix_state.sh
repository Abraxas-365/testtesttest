#!/bin/bash
set -e

# ============================================
# Quick Fix: Add 'state' column to sessions
# ============================================
# This is the CRITICAL fix for your ADK error.
# The full migration (004_fix_sessions_for_adk.sql) recreates everything.
# This script just adds the missing column if you want to keep existing data.

source deploy-config.sh

echo "======================================"
echo "🔧 Quick Fix: Add 'state' column to sessions"
echo "======================================"
echo ""
echo "⚠️  WARNING: This will add the 'state' column to your sessions table."
echo "⚠️  You will lose conversation history, but keep the table structure."
echo ""
read -p "Continue? (type 'yes'): " confirm

if [ "$confirm" != "yes" ]; then
    echo "❌ Cancelled"
    exit 0
fi

# Get connection details
export CONNECTION_NAME=$(gcloud sql instances describe $DB_INSTANCE_NAME \
  --format='value(connectionName)')

# Kill existing proxy
pkill -f cloud-sql-proxy 2>/dev/null || true
sleep 2

# Start proxy
echo ""
echo "🔌 Starting Cloud SQL Proxy..."
./cloud-sql-proxy $CONNECTION_NAME --port 5432 &
PROXY_PID=$!
sleep 5

cleanup() {
  echo ""
  echo "🧹 Cleaning up..."
  kill $PROXY_PID 2>/dev/null || true
  exit ${1:-0}
}

trap cleanup EXIT INT TERM

# Test connection
echo ""
echo "🔍 Testing database connection..."
if ! PGPASSWORD="$DB_APP_PASSWORD" psql -h 127.0.0.1 -p 5432 -U $DB_USER -d $DB_NAME -c "SELECT 1;" > /dev/null 2>&1; then
  echo "❌ Database connection failed"
  cleanup 1
fi

echo "✅ Connected to database"
echo ""

# Check if 'state' column already exists
echo "🔍 Checking if 'state' column exists..."
STATE_EXISTS=$(PGPASSWORD="$DB_APP_PASSWORD" psql -h 127.0.0.1 -p 5432 -U $DB_USER -d $DB_NAME -tAc \
  "SELECT COUNT(*) FROM information_schema.columns WHERE table_name='sessions' AND column_name='state';")

if [ "$STATE_EXISTS" -gt 0 ]; then
  echo "✅ 'state' column already exists! No fix needed."
  echo ""
  echo "If you're still getting errors, you may need to run the full migration:"
  echo "  ./run-migrations.sh"
  cleanup 0
fi

echo "❌ 'state' column is MISSING (this is the problem!)"
echo ""
echo "🔧 Adding 'state' column..."

# Add the state column
PGPASSWORD="$DB_APP_PASSWORD" psql -h 127.0.0.1 -p 5432 -U $DB_USER -d $DB_NAME <<'EOSQL'
-- Add the missing 'state' column
ALTER TABLE sessions ADD COLUMN state JSONB DEFAULT '{}'::jsonb NOT NULL;

-- Verify it was added
SELECT 
    column_name, 
    data_type, 
    is_nullable,
    column_default
FROM information_schema.columns 
WHERE table_name = 'sessions' 
AND column_name = 'state';
EOSQL

if [ $? -eq 0 ]; then
    echo ""
    echo "======================================"
    echo "✅ SUCCESS! 'state' column added!"
    echo "======================================"
    echo ""
    echo "🎉 Your ADK error should be fixed now!"
    echo ""
    echo "Next steps:"
    echo "1. Test your Teams integration:"
    echo "   Send a message in Teams"
    echo ""
    echo "2. If you still see errors, check logs:"
    echo "   gcloud logging tail \"resource.type=cloud_run_revision AND resource.labels.service_name=$SERVICE_NAME\" --project $PROJECT_ID"
    echo ""
else
    echo ""
    echo "❌ Failed to add 'state' column"
    cleanup 1
fi

cleanup 0
