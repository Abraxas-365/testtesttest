#!/bin/bash
set -e

source deploy-config.sh

echo "🔄 Redeploying $SERVICE_NAME..."

# Get connection name
export CONNECTION_NAME=$(gcloud sql instances describe $DB_INSTANCE_NAME \
  --format='value(connectionName)')

export PROJECT_NUMBER=$(gcloud projects describe $PROJECT_ID --format='value(projectNumber)')
export COMPUTE_SA="${PROJECT_NUMBER}-compute@developer.gserviceaccount.com"

# ==========================================
# Update Secrets (if changed)
# ==========================================
echo ""
echo "🔐 Updating secrets..."

# Update db-password
echo -n "$DB_APP_PASSWORD" | gcloud secrets versions add db-password --data-file=- || \
  echo -n "$DB_APP_PASSWORD" | gcloud secrets create db-password --data-file=- --replication-policy="automatic"

# Update graph-client-secret
echo -n "$GRAPH_CLIENT_SECRET" | gcloud secrets versions add graph-client-secret --data-file=- || \
  echo -n "$GRAPH_CLIENT_SECRET" | gcloud secrets create graph-client-secret --data-file=- --replication-policy="automatic"

# Grant access (idempotent)
gcloud secrets add-iam-policy-binding db-password \
  --member="serviceAccount:$COMPUTE_SA" \
  --role="roles/secretmanager.secretAccessor" \
  --no-user-output-enabled 2>/dev/null || true

gcloud secrets add-iam-policy-binding graph-client-secret \
  --member="serviceAccount:$COMPUTE_SA" \
  --role="roles/secretmanager.secretAccessor" \
  --no-user-output-enabled 2>/dev/null || true

echo "✅ Secrets updated"

# ==========================================
# Rebuild Container
# ==========================================
echo ""
echo "🏗️  Building new container image..."
gcloud builds submit --tag gcr.io/$PROJECT_ID/$SERVICE_NAME

# ==========================================
# Update Cloud Run Service
# ==========================================
echo ""
echo "🚀 Updating Cloud Run service..."

gcloud run services update $SERVICE_NAME \
  --image gcr.io/$PROJECT_ID/$SERVICE_NAME \
  --region $REGION \
  --add-cloudsql-instances $CONNECTION_NAME \
  --update-env-vars "ENVIRONMENT=production,DB_HOST=/cloudsql/$CONNECTION_NAME,DB_PORT=5432,DB_NAME=$DB_NAME,DB_USER=$DB_USER,GOOGLE_CLOUD_PROJECT=$PROJECT_ID,GOOGLE_GENAI_USE_VERTEXAI=TRUE,PERSIST_SESSIONS=true,GRAPH_TENANT_ID=$GRAPH_TENANT_ID,GRAPH_CLIENT_ID=$GRAPH_CLIENT_ID" \
  --update-secrets "DB_PASSWORD=db-password:latest,GRAPH_CLIENT_SECRET=graph-client-secret:latest"

# ==========================================
# Get Service URL
# ==========================================
export SERVICE_URL=$(gcloud run services describe $SERVICE_NAME \
  --region $REGION \
  --format 'value(status.url)')

echo ""
echo "======================================"
echo "✅ Redeployment complete!"
echo "======================================"
echo ""
echo "🌐 Service URL: $SERVICE_URL"
echo "📚 API Docs: $SERVICE_URL/docs"
echo ""
echo "🧪 Quick Test:"
echo "curl -H 'Authorization: Bearer \$(gcloud auth print-identity-token)' $SERVICE_URL/health"
echo ""
echo "📊 View Live Logs:"
echo "gcloud logging tail \"resource.type=cloud_run_revision AND resource.labels.service_name=$SERVICE_NAME\" --project $PROJECT_ID"
echo ""
echo "======================================"

